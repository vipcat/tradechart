import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Chart from './components/TVChartContainer'

ReactDOM.render(<Chart />, document.getElementById('tv-chart'));

